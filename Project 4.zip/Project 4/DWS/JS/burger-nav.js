$(document).ready(function(){
    $(".open-burger").on({
        click: function(){
            $(".multi-level").toggle(450);
        }
    });
});