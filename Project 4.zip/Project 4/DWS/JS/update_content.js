// var get_button = document.querySelector(".btn");
// var print_info = document.querySelector("#demo");
var list_content = document.querySelectorAll(".para-content");
var body = document.querySelector(".content-body");
var title_content = document.querySelectorAll(".title");
var illustration_content = document.querySelectorAll(".illustration");

var our_request; 

console.log(list_content);

body.onload = function(){
    
    if(window.XMLHttpRequest){
        our_request = new XMLHttpRequest();
    }else{
        our_request = new ActiveXObject(Microsoft.XMLHTTP);
    };

    our_request.onload = function(){
        var our_data = JSON.parse(our_request.responseText);
        renderHTML(our_data);
    };

    our_request.open('GET', 'http://localhost:3000/paragraphs', true);
    our_request.send();
};

function renderHTML(our_data){
    console.log(typeof(our_data[0]["content"]));
    console.log(our_data);
    console.log(illustration_content);
    
    for(var content = 0; content < list_content.length; content++){
        title_content[content].innerHTML = our_data[content]["title"];
        title_content[content].style.backgroundColor = "white";
        illustration_content[content].style.background = "url('" + our_data[content]["image"] + "') no-repeat";
        // illustration_content[content].style.backgroundSize = "auto";
        list_content[content].innerHTML = our_data[content]["content"];
    }
}


 

// "use strict";

// // let my_request = new Request("content_history.json");

// fetch("C:\\Users\\MY PC\\Desktop\\HTML and CSS\\Front-End(client software)\\Project 4\\DWS\\JSON\\content_history.json")
//     .then(function(resp){
//         return resp.json();
//     })

//     .then(function(data){
//         console.log(data);
//     });

// var mydata = JSON.parse(content_his);
