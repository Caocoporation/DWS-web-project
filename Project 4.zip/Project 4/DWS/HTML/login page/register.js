var error_message = document.querySelector(".all_error");
var list_check = document.querySelectorAll("input");
var list_error_check = document.querySelectorAll("#error");
var list_error_messages = document.querySelectorAll(".error_message");
var submit_btn = document.querySelector(".submit-button");
var checkbox = document.querySelector(".checkbox");

// function

var order_examination = true;

submit_btn.addEventListener("click", function(){
    check_all();
    // navigator(order_examination);
})


// check fields
console.log(list_check);
console.log(list_check[0].value);
console.log(error_message.innerHTML);
console.log(list_error_check);
console.log(list_error_messages);


function check_all(){
    for(var item = 0; item < (list_check.length - 4); item++){
        if(list_check[item].value == ""){
            error_message.innerHTML = list_of_error[0]["error"]["empty_all_fields_error"];
            list_error_check[item].style.color = list_of_error[2]["warning"]["warning_color"];
            error_message.style.background = list_of_error[2]["warning"]["warning_bg_color"];
            list_error_check[item].style.backgroundImage = list_of_error[0]["error"]["error_icon"];
            list_error_check[item].style.backgroundRepeat = "no-repeat";
            list_error_check[item].style.backgroundPosition = "center";
            list_error_messages[item].innerHTML = list_of_error[0]["error"]["empty_field_error"];
            list_error_messages[item].style.background = list_of_error[0]["error"]["error_bg_color"];
            order_examination = false;
            console.log(order_examination);
            // return order_examination;
        }
    }
    detail_checker();
}

var list_of_error = [
    {
        "error":{   
            "empty_all_fields_error": "You have to fill in all the fields of the form.",
            "empty_field_error": "You have to fill in this field",
            "length_error": "Your username has to be at least 8 characters.",
            "first_character_error": "The first character cannot be special characters", 
            "number_error": "Your username should have at least 1 number.",
            "uppercase_error": "Your username should have at least 1 character in uppercase.",
            "repeated_password": "The confirmed password has to be the same with the password.",
            "error_color": "red",
            "error_bg_color": "#f5562f",
            "error_icon": "url('./images/cross_sign.png')",
            "confirm_password": "You have to confirm your password.",
            "email_format": "Your email address has to be in the right format (For example: example@gmail.com)",
            "repeated_email":"The confirmed email has to be the same with the provided email.",
            "recheck_email": "Check your email before confirming it !",
            "recheck_address": "Check your address",
            "fill_in_checkbox": "You have to fill in the checkbox."
        }
    },

    {
        "success":{
            "can_use_username":"You can use this username!", 
            "can_use_password":"You can use this password!", 
            "email_success": "It's good to use !",
            "success_color": "green",
            "success_bg_color":"#68f21d",
            "success_icon": "url('./images/check_mark.png')",
            "confirm_re_password": "Successfully !",
            "confirm_re_email":"Successfully !",
            "name": "Good !",
            "address_sucess": "Valid !"
        }    
    },

    {
        "warning":{
            "warning_password": "You can use but it is not strong enough",
            "warning_color": "black",
            "warning_bg_color": "#f7ef0a",
            "warning_icon": "url('./images/check_icon_2.png')"
        }    
    }
];

var index;
function detail_checker(){
        username_checker();
        password_checker();
        email_checker();
        name_checker();
        address_checker();
        checkbox_checker();
        console.log(order_examination);
        navigator(order_examination);
}

// console.log(list_of_error[0]["length_error"]);
var special_character = ["!", "#", "$","%","&"," '","`","*","+","-","/","=","?","^","_","{","}", "|", "@" ];

console.log(list_error_check);


// var index_list = 0;

console.log(list_of_error);

function username_checker(){
    // console.log(list_check[0].value);
    // console.log(typeof(list_of_error));
    var sub_index = 0;
    
    check_on_field(sub_index);
}

function password_checker(){
    var sub_index = 1;
    
    check_on_field(sub_index);

    if(list_check[sub_index + 1].value == ""){
        list_error_messages[sub_index + 1].innerHTML = list_of_error[0]["error"]["empty_field_error"];
        error_icon(sub_index + 1);
    }else if(list_check[sub_index + 1].value != list_check[1].value){
        list_error_messages[sub_index + 1].innerHTML = list_of_error[0]["error"]["repeated_password"];
        error_icon(sub_index + 1);
    }else{
        if(list_check[sub_index + 1].value == list_check[1].value){
            list_error_messages[sub_index + 1].innerHTML = list_of_error[1]["success"]["confirm_re_password"];
            success_icon(sub_index + 1);
        }
    }
}
function email_checker(){
    var sub_index = 3;
    
    console.log(list_check[sub_index].value);

    // /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ full explaination of this statement is in the 
    // https://www.w3resource.com/javascript/form/email-validation.php

    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

    console.log(re.test(list_check[sub_index].value));

    if(list_check[sub_index].value == ""){
        error_icon(sub_index);
        list_error_messages[sub_index].innerHTML = list_of_error[0]["error"]["empty_field_error"];
        error_icon(sub_index);
    }else{
        if(re.test(list_check[sub_index].value)){
            success_icon(sub_index);
            list_error_messages[sub_index].innerHTML = list_of_error[1]["success"]["email_success"];
            if(list_check[sub_index + 1].value == ""){
                console.log(`The value of sub index is: ${sub_index}`);
                error_icon(sub_index + 1);
                list_error_messages[sub_index + 1].innerHTML = list_of_error[0]["error"]["empty_field_error"];
            }else{
                if(list_check[sub_index + 1].value == list_check[3].value && (list_check[sub_index].value).length != 0){
                    success_icon(sub_index + 1);
                    list_error_messages[sub_index + 1].innerHTML = list_of_error[1]["success"]["confirm_re_email"];
                }else{
                    error_icon(sub_index + 1);
                    list_error_messages[sub_index + 1].innerHTML = list_of_error[0]["error"]["repeated_email"];
                }
            } 
        }
        else{
            error_icon(sub_index);
            list_error_messages[sub_index].innerHTML = list_of_error[0]["error"]["email_format"];
            if(list_check[sub_index + 1].value.length > 0){
                list_error_messages[sub_index + 1].innerHTML = list_of_error[0]["error"]["recheck_email"];
                error_icon(sub_index + 1);
            }
        }
    }  
}

function name_checker(){
    var sub_index;
    for(var i = 0; i < 2; i++){
        if(i == 0){
            sub_index = 5;
            name_checker_2(sub_index);
        }else if( i == 1){
            sub_index = 6;
            name_checker_2(sub_index);
        }
    }
}

function name_checker_2(sub_index){
    if(list_check[sub_index].value.length == 0){
        error_icon(sub_index);
        list_error_messages[sub_index].innerHTML = list_of_error[0]["error"]["empty_field_error"];
    }else{
        success_icon(sub_index);
        list_error_messages[sub_index].innerHTML = list_of_error[1]["success"]["name"];
    }
}

function address_checker(){
   var  sub_index = 7;
   var  address_form = /^[a-zA-Z0-9\s,.'-]{3,}$/;
//    check_on_field(sub_index);
   if(list_check[sub_index].value == 0){
        list_error_messages[sub_index + 1].innerHTML = list_of_error[0]["error"]["empty_field_error"];
        error_icon(sub_index + 1);
   }else{
       if(address_form.test(list_check[sub_index].value)){
            list_error_messages[sub_index + 1].innerHTML = list_of_error[1]["success"]["address_sucess"];
            success_icon(sub_index + 1);
       }else{
            list_error_messages[sub_index + 1].innerHTML = list_of_error[0]["error"]["recheck_address"];
            error_icon(sub_index + 1);
       }
   }
}

function checkbox_checker(){
    var sub_index = 9;

    if(checkbox.checked){
        success_icon(sub_index);
        list_error_messages[sub_index].innerHTML = "";
        list_error_messages[sub_index].style.background = "whitesmoke";
        if(order_examination){
            for(var i = 0; i < list_check.length; i++){
                if(list_check[i].value ==""){
                    order_examination = false;
                }else{
                    order_examination = true;
                }
            }
        }
    }else{
        error_icon(sub_index);
        list_error_messages[sub_index].innerHTML = list_of_error[0]["error"]["fill_in_checkbox"];
    }
}


function check_on_field(sub_index){
    console.log(sub_index);
    let sub_index_2 = sub_index;
    console.log(sub_index_2);
    console.log(list_check[sub_index_2].value);

    if((list_check[sub_index_2].value).length == 0){
        list_error_messages[sub_index].innerHTML = list_of_error[0]["error"]["empty_field_error"];
        error_icon(sub_index);
    }else{
        if((list_check[sub_index].value).length < 8 || ((list_check[sub_index].value).length > 50 )){
            list_error_check[sub_index].innerHTML = " ";
            list_error_messages[sub_index].innerHTML = list_of_error[0]["error"]["length_error"];
            error_icon(sub_index); 
        }else{
            for(char of special_character){

                if((list_check[sub_index].value)[0].indexOf(char) == -1){
                    if(sub_index == 0){
                        list_error_messages[sub_index].innerHTML = list_of_error[1]["success"]["can_use_username"];
                    }else if(sub_index == 1){
                        list_error_messages[sub_index].innerHTML = list_of_error[1]["success"]["can_use_password"];
                    }    
                    success_icon(sub_index_2);
                }else if((list_check[sub_index].value)[0].indexOf(char) == 0){
                    error_icon(sub_index); 
                    list_error_messages[sub_index].innerHTML = list_of_error[0]["error"]["first_character_error"];
                    break;
                }
            }
        }
    }
}

var error_warning = document.querySelector(".error_warning");
var congrat = document.querySelector(".success");
var title = document.querySelector(".modal-title");

function navigator(order_examination){
    if(order_examination){
        title.innerHTML = "Successfully !"
        error_warning.innerHTML = "Please! Wait for a few seconds to get to login page."
        announcement();
    }else{
        error_warning.innerHTML = "Please! Fill in the form first"
    }
}

function announcement(){
    setInterval(function(){
        document.querySelector(".take_data").submit();
    }, 3000);
}


function error_icon(sub_index){
    list_error_check[sub_index].style.backgroundImage = list_of_error[0]["error"]["error_icon"];
    list_error_check[sub_index].style.backgroundRepeat = "no-repeat";
    list_error_check[sub_index].style.backgroundPosition = "center";
    list_error_messages[sub_index].style.background = list_of_error[0]["error"]["error_bg_color"];
    order_examination = false;
    return order_examination
}

function success_icon(sub_index){
    list_error_check[sub_index].style.backgroundImage = list_of_error[1]["success"]["success_icon"];
    list_error_check[sub_index].style.backgroundRepeat = "no-repeat";
    list_error_check[sub_index].style.backgroundPosition = "center";
    list_error_messages[sub_index].style.background = list_of_error[1]["success"]["success_bg_color"];
    order_examination = true;
    return order_examination
};













