var url = "http://localhost:3000/admin";
var confirm = true;
var take_id = 0;


$(document).ready(function () {
    $(".submit-button").on("click", function(){
        var  get_username =  $("#take_name");
        var  get_password = $("#take_password");
        console.log(get_username.val());

        $.getJSON(url, function (data) {
                // console.log(data);
                $.each(data, function(i, item){
                    
                    if(get_username.val() == item.username){
                        if(get_password.val() == item.password){
                            confirm = true;
                            take_id = item.id;
                        }else{
                            confirm = false;
                            $(".error_warning").text("Your account is invalid.");
                            $(".error_warning").css({
                                "color": "red",
                                "margin-bottom": "10px"
                            })
                        }
                    }
                    console.log(confirm);
                    if(confirm){
                        confirm = false;
                        $(".take_account").submit();   
                    }
                  });
            }
        );
    })
})

// function id_user(){
//     var get_id = take_id;  
//     return get_id;
// }



